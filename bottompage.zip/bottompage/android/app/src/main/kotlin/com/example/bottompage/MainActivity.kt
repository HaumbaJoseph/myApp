package com.example.bottompage

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
